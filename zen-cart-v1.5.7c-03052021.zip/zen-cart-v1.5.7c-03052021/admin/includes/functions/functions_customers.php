<?php
/**
 * /admin/includes/functions/functions_customers
 *
 */

// ALERT: As of v1.5.6 all these functions were moved to catalog-side
// so they are now found in /includes/functions/functions_customers.php
