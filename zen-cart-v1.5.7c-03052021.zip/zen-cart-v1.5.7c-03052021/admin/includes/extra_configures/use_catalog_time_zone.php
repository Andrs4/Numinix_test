<?php
/**
 * @package admin
 * @copyright Copyright 2003-2013 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version GIT: $Id: Author: DrByte  Sat Nov 2 01:21:28 2013 -0400 New in v1.5.2 $
 */
// get time zone settings from catalog-side file
include (DIR_FS_CATALOG . '/includes/extra_configures/set_time_zone.php');
